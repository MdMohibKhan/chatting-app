from django import forms
#it create form for user registration in signupPage.html page
class UserRegistration(forms.Form):
    Name=forms.CharField()
    Email=forms.EmailField()
    Password=forms.CharField()
    Conform_Password=forms.CharField()

#it create form for user login in loginPage.html page
class UserLogin(forms.Form):
    Email=forms.EmailField()
    Password=forms.CharField(widget=forms.PasswordInput)
#it create form for getting chat test from chats.html page
class getMsg(forms.Form):
    Message=forms.Textarea()