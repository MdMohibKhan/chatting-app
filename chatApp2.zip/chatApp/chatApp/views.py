from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.db import connection
from .models import *
from .forms import UserRegistration,UserLogin
import datetime

#This method will call when user hit this url http://127.0.0.1:8000/ on web-browser
def loginPgFun(request):
    try:
        del request.session['currentU']
        del request.session['chatWith']
    except KeyError:
        pass
    if request.method == 'POST':
        fm=UserLogin(request.POST)
        if fm.is_valid():
            pas=getUserPass('users',fm.cleaned_data['Email'])
            if pas!="error":
                if pas!=None and pas[0]==fm.cleaned_data['Password']:
                    currentUser=fm.cleaned_data['Email']
                    contacts=getNameEmail() #this Method return tuple which contain every users name and email
                    allUname=[]
                    allUemail=[]
                    noOfChats=[]
                    for user in contacts:
                        allUname.append(user[0]) #collecting every users name in one array
                        allUemail.append(user[1]) #collecting every users email in one array
                        noOfChats.append(getNoOfChats(currentUser,user[1])[0])
                    request.session['currentU']=currentUser # creating session to store current loged in users email

                    return render(request,'chats.html',{'msg':'','allUname':allUname,'allUemail':allUemail,'currentUser':currentUser,'chats':'','SelectedUseToChat':'','noOfChats':noOfChats})
                else:
                    return render(request,'loginPage.html',{'form':fm,'msg':'','sorryMsg':'Email/Password Invalid..!!-1'})
            else:
                return render(request,'loginPage.html',{'form':fm,'msg':'','sorryMsg':'Email/Password Invalid..!!-2'})
        else:
            return render(request,'loginPage.html',{'form':fm,'msg':'','sorryMsg':'Email/Password Invalid..!!-3'})
    else:
        fm=UserLogin() #if request method not POST redirect page to login page
        return render(request,'loginPage.html',{'form':fm,'msg':'','sorryMsg':''})

# This function will call when signup link is clicked
def signupPgFun(request):
    if request.method == 'POST':
        fm=UserRegistration(request.POST)
        if fm.is_valid(): #this is validate form
            if fm.cleaned_data['Password']==fm.cleaned_data['Conform_Password']: #this will check both password and verify password is same or not
                checkUser=getUserPass('users',fm.cleaned_data['Email']) # fetching password from users table of given email if user exist
                if checkUser!="error": # if user is exist then getUserPass() return password of that user otherwise return error as string
                    if getUserPass('users',fm.cleaned_data['Email'])==None: # if user is not exist previously then create new user
                        #creating new user
                        addNuser=addNewUser(fm.cleaned_data['Name'],fm.cleaned_data['Email'],fm.cleaned_data['Password'])
                        createChatTb=createNewUserChatTb(fm.cleaned_data['Email'].split("@")[0])
                        if addNuser!=False and createChatTb!=False: #checking user created or not
                            fm=UserRegistration() # if user created 
                            return render(request,'signupPage.html',{'form':fm,'msg':'User Created'})
                        else:
                            # if USER Not Created
                            return render(request,'signupPage.html',{'form':fm,'msg':'Somthing Going wrong..!'})
                    else:
                        # if USER Already exist
                        return render(request,'signupPage.html',{'form':fm,'msg':'User already exist'})
                else:
                    # if some error occur
                    return render(request,'signupPage.html',{'form':fm,'msg':'Somthing Going wrong..!!'})
            else:
                # if both password not same
                return render(request,'signupPage.html',{'form':fm,'msg':'Both passwords must match'})
    else:
         # if method not POST
        fm=UserRegistration()
    return render(request,'signupPage.html',{'form':fm,'msg':''})

# It Will return Selected users Details
def selectedUser(request):
    try:
        selected= request.POST.get('selectedusername') # getting selected contacts name amd email
        currentUser=request.session.get('currentU') # getting current loing users email 
        ChatTo=selected.split('(')[1]
        userToChat=ChatTo.split(')')[0] # collecting selected contacts email
        contacts=getNameEmail() #this Method return table which contain every users name and email
        allUname=[]
        allUemail=[]
        noOfChats=[]
        for user in contacts:
            allUname.append(user[0]) #collecting every users name in one array
            allUemail.append(user[1]) #collecting every users email in one array
            noOfChats.append(getNoOfChats(currentUser,user[1])[0])
        chatsArr=getChatsOf(currentUser,userToChat)# getting all chats between two users
        request.session['chatWith']=userToChat # creating session to store current slected contact/email
        return render(request,'chats.html',{'msg':'','allUname':allUname,'allUemail':allUemail,'currentUser':currentUser,'chats':chatsArr,'SelectedUseToChat':"("+userToChat+")",'noOfChats':noOfChats})
    except Exception as e:
        fm=UserLogin() #if request method not POST redirect page to login page
        return render(request,'loginPage.html',{'form':fm,'msg':'','sorryMsg':''})
def forgotPgFun(request):
    return render(request,'forgotPassPage.html',{'stus':'','emailval':'example@gmail.com'})

def otpfun(request):
    return render(request,'forgotPassPage.html',{'stus':'getOtp','msg':'OTP has been sent to your email id','emailval':'example@gmail.com'})

def otpSubfun(request):
    return render(request,'forgotPassPage.html',{'stus':'setNewPass','emailval':'example@gmail.com'})
def updateNewPass(request):
    return render(request,'loginPage.html',{'msg':'Your password has been updated successfully'})

    # this funtion will call when user click on send button in chats.html page
def sendNewMsgfun(request):
    try:
        currentUser=request.session.get('currentU') #fetching current logedin user email
        try:
            userToChat=request.session.get('chatWith') #fetching slected user email
            print("#### Selected Contacts : "+userToChat)
            massage= request.POST.get('NewMsg') #fetching message text
            if(massage != ""):
                currentDateTime=datetime.datetime.now() #getting current date and time
                flag=insertChats(currentUser,userToChat,massage,currentDateTime) #inserting message into both users chat table
                if(flag):
                    print("Chat Inserted")
                else:
                    print("Chat Not Inserted")
                
                chatsArr=getChatsOf(currentUser,userToChat)# getting all chats between two users
                contacts=getNameEmail() #this Method return table which contain every users name and email
                allUname=[]
                allUemail=[]
                noOfChats=[]
                for user in contacts:
                    allUname.append(user[0])  #collecting every users name in one array
                    allUemail.append(user[1])  #collecting every users email in one array
                    noOfChats.append(getNoOfChats(currentUser,user[1])[0])
                return render(request,'chats.html',{'msg':'','allUname':allUname,'allUemail':allUemail,'currentUser':currentUser,'chats':chatsArr,'SelectedUseToChat':"("+userToChat+")",'noOfChats':noOfChats})
            else:
                chatsArr=getChatsOf(currentUser,userToChat) # getting all chats between two users
                contacts=getNameEmail() #this Method return table which contain every users name and email
                allUname=[]
                allUemail=[]
                noOfChats=[]
                for user in contacts:
                    allUname.append(user[0])  #collecting every users name in one array
                    allUemail.append(user[1])  #collecting every users email in one array
                    noOfChats.append(getNoOfChats(currentUser,user[1])[0])
                return render(request,'chats.html',{'msg':'First Write Message','allUname':allUname,'allUemail':allUemail,'currentUser':currentUser,'chats':chatsArr,'SelectedUseToChat':"("+userToChat+")",'noOfChats':noOfChats})
        except Exception as ee:
            chatsArr=getChatsOf(currentUser,userToChat) # getting all chats between two users
            contacts=getNameEmail() #this Method return table which contain every users name and email
            allUname=[]
            allUemail=[]
            noOfChats=[]
            for user in contacts:
                allUname.append(user[0])  #collecting every users name in one array
                allUemail.append(user[1])  #collecting every users email in one array
                noOfChats.append(getNoOfChats(currentUser,user[1])[0])
            return render(request,'chats.html',{'msg':'First Select Contact','allUname':allUname,'allUemail':allUemail,'currentUser':currentUser,'chats':chatsArr,'SelectedUseToChat':'','noOfChats':noOfChats})
        
    except Exception as e:
        fm=UserLogin() #if request method not POST redirect page to login page
        return render(request,'loginPage.html',{'form':fm,'msg':'','sorryMsg':'First Login..!'})
    
# This function return all chats between two users
def getChatsOf(currentUser,userToChat):
    chats=getUserChats(currentUser,userToChat) #fetching selected users and logedin users chats from database
    if(chats=="error"): #if error occur at fetching users chats
        print("Chat error")
        chatsArr=""
    else:
        chatsArr=[]
        for user in chats:
            for i in range(0,len(user)):
                if(i==3): # in every 3rd index have datetime.datetime 
                    chatsArr.append(user[i].strftime("%m/%d/%Y, %H:%M:%S")) #converting datetime.datetime  into string
                else:
                    chatsArr.append(user[i])
    return chatsArr


   
