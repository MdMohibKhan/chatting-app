//this funtion adds values in select option to display all chats
function chatContactsFun(allUname,allUemail,currentUser,noOfChats) {
  var selectChatCon = document.getElementById('chatcontactsId');
  len=allUemail.length
  if(len>0){
    for (var i=0; i<len; i++) {
      if(allUemail[i]!=null){
        if(currentUser!=allUemail[i]){
          selectChatCon.options[selectChatCon.options.length] = new Option(allUname[i]+"("+allUemail[i]+")"+"{"+noOfChats[i]+"}", i);
        }
      }
    }
    //calling function to select selected user after page load
    //getSelectedChat();
  }

}



