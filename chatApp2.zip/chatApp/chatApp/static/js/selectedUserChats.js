
//This function adds all users into select option
function addChatsFun(chats,currentUser){
    var size=chats.length;
    var i
    for(i=0;i<size;){
        var sender=chats[i++];
        var receiver=chats[i++];
        var msg=chats[i++];
        var timedate=chats[i++];
        var cls="";
        if(sender==currentUser){
            cls='container1';
        }
        else{
            cls='container2';
        }
        addChats(msg,cls,timedate);
    }
  } 

//This function will call for collecting selected-contact when onchang event occur at select option in chatContacts form
function selectedChats(currentUser){
    var index = document.getElementById("chatcontactsId").selectedIndex;
    var options = document.getElementById("chatcontactsId").options;
    user=options[index].text;
    var selectedText=document.getElementById("selecteduserid");
    selectedText.value=user;//selected contact is passed in Temporary TextField to send server by post
    //creating and updating cookie to maintain selected option in chat.html
    setCookie("selectedU",user,1);
    setCookie("selectedInx",index,1);
    //document.getElementById("currentUid").value=currentUser;
    document.getElementById('selecteduserfid').submit();
    
}

//Display updated current selected users chats currentUserLogedin
function getSelectedChat(){
    if(getCookie("selectedU")!="" && getCookie("selectedInx")!=null){
        document.getElementById("chatcontactsId").selectedIndex = getCookie("selectedInx"); 
        //addChatsFun([getCookie("chats")],""+getCookie("currentUserLogedin"));
    }
}

//function to create/set cookie 
function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  
  //function to get cookie value
  function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  function deleteCookies(){
    document.cookie ="selectedU=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie ="selectedInx=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    
  }