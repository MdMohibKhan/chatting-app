from django.apps import AppConfig


class UserregistrationConfig(AppConfig):
    name = 'userRegistration'
