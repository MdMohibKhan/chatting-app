"""chatApp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from .views import otpSubfun,otpfun,loginPgFun,signupPgFun,forgotPgFun,updateNewPass,sendNewMsgfun,selectedUser
from django.conf.urls import url


urlpatterns = [
    path('admin/', admin.site.urls),

    path('',loginPgFun,name='loginPgFun'), #This is home page /Login page
    path('signupPg/',signupPgFun,name='signupPgFun'), #calling signupPgFun() To signup
    path('selectedContact/newMassege/',sendNewMsgfun,name='sendNewMsgfun'), #To display all contacts
    path('selectedContact/',selectedUser,name='selectedContact'), #to display seleted users chats
    
    # Thise will use in future
    path('otpPass/',otpfun,name='optfun'),
    path('otpSubPass/',otpSubfun,name='optSubfn'),
    path('updatedPass/',updateNewPass,name='updateNewPass'),
    path('forgotPassPg/',forgotPgFun,name='forgotPgFun'),
    
]
