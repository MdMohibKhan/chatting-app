from django.db import models
from django.db import connection

#This function will create Users table
def createUsersTB():
    try:
        cursor = connection.cursor()
        cursor.execute("create table users(name varchar(50) NOT NULL, email varchar(50) NOT NULL, password varchar(50) NOT NULL, PRIMARY KEY (email));")
        print("Users Table Created Successfully..!!")
        return True
    except Exception as e:
        print(e)
        return False
# This function will create chat table for every user
def createNewUserChatTb(tableName):
    try:
        cursor = connection.cursor()
        cursor.execute("create table "+tableName+"(sender varchar(50) NOT NULL,receiver varchar(50) NOT NULL,msg TEXT NOT NULL, timedate TIMESTAMP NOT NULL);")
        return True
    except Exception as e:
        print(e)
        return False
# This function Store registered users details
def addNewUser(name,email,password):
    try:
        cursor = connection.cursor()
        sql="insert into users(name,email,password) values(%s,%s,%s);"
        cursor.execute(sql,[name,email,password])
        return True
    except Exception as e:
        print(e)
        return False

# This funtion add chats into of user on his/her table
def addChats(tableName,sender,receiver,msg):
    try:
        cursor = connection.cursor()
        sql="insert into "+tableName+" values(%s,%s,%s);"
        cursor.execute(sql,[tableName,sender,receiver,msg])
        return True
    except Exception as e:
        print(e)
        return False

# This function update new password of existing user
def updateUserPass(newPass,email):
    try:
        cursor = connection.cursor()
        sql="UPDATE users SET password=%s WHERE email=%s"
        cursor.execute(sql,[newPass,email])
        return True
    except Exception as e:
        print(e)
        return False

 # This funtion return password of exusting user
def getUserPass(tableName,email):
    try:
        cursor = connection.cursor()
        sql="select password from users WHERE email=%s"
        cursor.execute(sql,[email])
        password=cursor.fetchone()
        return password;
    except Exception as e:
        print(e)
        return("error")

 # This function delete the particuler chats of particuler user
def deleteChat(tableName,sender,receiver,datetime):
    cursor = connection.cursor()
    sql="delete from "+tableName+" WHERE sender=%s and receiver=%s and timedate=%s"
    password=cursor.execute(sql,[sender,receiver,datetime])

# This function return user name and email for use in as a contacts
def getNameEmail():
    try:
        cursor = connection.cursor()
        sql="select name,email from users"
        cursor.execute(sql)
        namePass=cursor.fetchall()
        return namePass;
    except Exception as e:
        print(e)
        return("error")

# This function return particuler users chats
def getUserChats(firstUser,SecondUser):
    try:
        firstUserTb=firstUser.split('@')[0]
        cursor = connection.cursor()
        sql="select * from "+firstUserTb+" WHERE sender=%s and receiver=%s or sender=%s and receiver=%s order by timedate;"
        cursor.execute(sql,[firstUser,SecondUser,SecondUser,firstUser])
        chats=cursor.fetchall()
        return chats;
    except Exception as e:
        print(e)
        return("error")

# This function store chats
def insertChats(sender,receiver,msgs,currentDateTime):
    try:
        senderTb=sender.split('@')[0]
        receiverTb=receiver.split('@')[0]
        sql1="insert into "+senderTb+"(sender,receiver,msg,timedate) values(%s,%s,%s,%s);"
        sql2="insert into "+receiverTb+"(sender,receiver,msg,timedate) values(%s,%s,%s,%s);"
        cursor = connection.cursor()
        cursor.execute(sql1,[sender,receiver,msgs,currentDateTime])
        cursor.execute(sql2,[sender,receiver,msgs,currentDateTime])
        return True
    except Exception as e:
        print("Exception in Chat Insert : ",e)
        return False
