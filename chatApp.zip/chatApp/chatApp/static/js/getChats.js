//This funtion display chats into div elements 
function addChats(msg,cls,time){
    var rootdiv=document.getElementById('chatcontainerid');//chats container
    var div=document.createElement("div");//div element to contain one Message
    var p=document.createElement("p");//p element for Text Message
    var span=document.createElement("span");//span element for Date Time
    var attr=document.createAttribute("id");
  
    div.classList+=cls;
    span.classList+='containert';
  //setting value in each elements 
    p.innerHTML=msg;
    span.innerHTML=time;
    attr.value="container1";//here I use two attr value 'container1' and 'container2' to change color of message
  
    div.setAttributeNode(attr);
    div.appendChild(p);
    div.appendChild(span);
    rootdiv.appendChild(div);
  
  }
  