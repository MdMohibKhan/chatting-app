from django.contrib import admin
from django.urls import path, include
from userRegistration import views
from .views import home,loginfun,signupfun,forgotfun,otpfun,otpSubfun,updatePassfun,voiceToText,GetUser
from dashboard.views import 


urlpatternns=[
    path('admin/',admin.site.urls),
    path('',views.index,name='userLogin'),
    path('registration/',views.index,name='userRegistration'),
    path('dashboard/',views.index,name='dashboard'),
]